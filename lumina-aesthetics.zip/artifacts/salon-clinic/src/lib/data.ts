export const services = [
  {
    id: 'hydrafacial',
    name: 'HydraFacial',
    slug: 'hydrafacial',
    shortDesc: 'Deep cleansing, hydration and glow',
    duration: '45 mins',
    price: 'From PKR 8,000',
    icon: 'Droplets'
  },
  {
    id: 'prp-facial',
    name: 'PRP Facial',
    slug: 'prp-facial',
    shortDesc: 'Platelet-rich plasma for skin renewal',
    duration: '60 mins',
    price: 'From PKR 15,000',
    icon: 'Sparkles'
  },
  {
    id: 'hair-prp',
    name: 'Hair PRP',
    slug: 'hair-prp',
    shortDesc: 'PRP therapy for hair restoration',
    duration: '45 mins',
    price: 'From PKR 18,000',
    icon: 'Activity'
  },
  {
    id: 'laser-hair-removal',
    name: 'Laser Hair Removal',
    slug: 'laser-hair-removal',
    shortDesc: 'Permanent hair reduction with advanced lasers',
    duration: '30–90 mins',
    price: 'From PKR 3,500',
    icon: 'Zap'
  },
  {
    id: 'hifu',
    name: 'HIFU',
    slug: 'hifu',
    shortDesc: 'High-Intensity Focused Ultrasound skin tightening',
    duration: '90 mins',
    price: 'From PKR 35,000',
    icon: 'Waves'
  },
  {
    id: 'electrocautery',
    name: 'Electrocautery',
    slug: 'electrocautery',
    shortDesc: 'Precise skin lesion removal',
    duration: '30 mins',
    price: 'From PKR 6,000',
    icon: 'Target'
  },
  {
    id: 'skin-rejuvenation',
    name: 'Skin Rejuvenation',
    slug: 'skin-rejuvenation',
    shortDesc: 'Multi-modal skin revitalization',
    duration: '60 mins',
    price: 'From PKR 10,000',
    icon: 'Sun'
  },
  {
    id: 'acne-treatment',
    name: 'Acne Treatment',
    slug: 'acne-treatment',
    shortDesc: 'Medical-grade acne solutions',
    duration: '45 mins',
    price: 'From PKR 5,000',
    icon: 'ShieldAlert'
  },
  {
    id: 'pigmentation-treatment',
    name: 'Pigmentation Treatment',
    slug: 'pigmentation-treatment',
    shortDesc: 'Even skin tone treatments',
    duration: '45 mins',
    price: 'From PKR 7,500',
    icon: 'Aperture'
  },
  {
    id: 'anti-aging',
    name: 'Anti Aging',
    slug: 'anti-aging',
    shortDesc: 'Advanced anti-aging protocols',
    duration: '60 mins',
    price: 'From PKR 12,000',
    icon: 'Clock'
  },
  {
    id: 'skin-tightening',
    name: 'Skin Tightening',
    slug: 'skin-tightening',
    shortDesc: 'Non-surgical lifting and firming',
    duration: '60 mins',
    price: 'From PKR 20,000',
    icon: 'Feather'
  },
  {
    id: 'skin-analysis',
    name: 'Skin Analysis',
    slug: 'skin-analysis',
    shortDesc: 'Advanced AI-powered skin assessment',
    duration: '30 mins',
    price: 'From PKR 2,000',
    icon: 'ScanSearch'
  }
];

export const team = [
  {
    name: "Dr. Ayesha Malik",
    role: "Medical Director & Founder",
    credentials: "MBBS, FCPS (Dermatology)",
    bio: "With over 15 years in aesthetic medicine, Dr. Ayesha Malik built Lumina Aesthetics on the principle that every patient deserves bespoke, science-driven care. Her treatments are known for their precision and naturally beautiful results.",
    image: "/images/doctor-1.jpg"
  },
  {
    name: "Dr. Zain Hassan",
    role: "Lead Aesthetic Physician",
    credentials: "MBBS, Diploma in Aesthetic Medicine",
    bio: "Specializing in laser aesthetics and complex pigmentation correction, Dr. Zain Hassan brings a meticulous, evidence-based approach to every treatment, ensuring safe and lasting outcomes.",
    image: "/images/doctor-2.jpg"
  },
  {
    name: "Hina Raza",
    role: "Senior Aesthetician",
    credentials: "Licensed Aesthetician, Master Injector",
    bio: "An artist with dermal fillers and a master of facial balancing, Hina's gentle touch and artistic eye have earned her a devoted clientele across Lahore.",
    image: "/images/testimonial-1.jpg"
  }
];

export const faqs = [
  {
    category: "General",
    questions: [
      { q: "Are all treatments supervised by a doctor?", a: "Yes. Every treatment protocol at Lumina is designed and overseen by our board-certified medical directors. Complex procedures are performed exclusively by qualified physicians." },
      { q: "Is the clinic environment safe and sterile?", a: "Absolutely. We operate at medical-grade hygiene standards. Our clinic features hospital-grade air filtration and strict sterilisation protocols registered with the Punjab Healthcare Commission (PHC)." },
      { q: "What should I expect during my first visit?", a: "Your first visit includes a comprehensive AI-powered skin analysis and a detailed consultation to understand your goals before any treatment begins." },
      { q: "Do you treat all skin types?", a: "Yes. We have specialised lasers and treatment protocols safe and effective for all Fitzpatrick skin types (I-VI), including the darker complexions common in Pakistan." },
      { q: "How long has Lumina Aesthetics been operating?", a: "Lumina Aesthetics was founded over 10 years ago in Lahore, establishing itself as a premier destination for luxury aesthetic medicine in Pakistan." }
    ]
  },
  {
    category: "Treatments",
    questions: [
      { q: "Do the treatments hurt?", a: "Most of our treatments are non-invasive and painless. For procedures that may cause discomfort, we use premium topical numbing creams and cooling systems to ensure your comfort." },
      { q: "What is the downtime after a HydraFacial?", a: "There is zero downtime after a HydraFacial. You can immediately return to your daily activities with a radiant glow." },
      { q: "How many sessions of Laser Hair Removal do I need?", a: "Typically, 6 to 8 sessions spaced 4–6 weeks apart are recommended for optimal permanent hair reduction, depending on hair and skin type." },
      { q: "Is PRP safe?", a: "Yes. PRP (Platelet-Rich Plasma) uses your own blood, eliminating the risk of allergic reactions. It is a completely natural way to stimulate collagen and healing." },
      { q: "How long do HIFU results last?", a: "HIFU results typically last 12 to 18 months. Maintenance sessions can prolong the lifting and firming effects." },
      { q: "Can I wear makeup after a peel?", a: "We recommend waiting at least 24 hours before applying makeup to allow the skin to breathe and heal." },
      { q: "What is the difference between Botox and Fillers?", a: "Botox relaxes muscles that cause wrinkles (like frown lines), while fillers restore lost volume and contour areas like cheeks and lips." },
      { q: "Is your technology internationally certified?", a: "Yes. We exclusively use internationally certified, industry-leading technology from globally recognised medical device manufacturers." }
    ]
  },
  {
    category: "Booking",
    questions: [
      { q: "How far in advance should I book?", a: "We recommend booking at least one week in advance to secure your preferred date and time, especially for evening and weekend appointments." },
      { q: "What is your cancellation policy?", a: "We require 48 hours notice for cancellations or rescheduling. Late cancellations may incur a fee." },
      { q: "Do you offer consultation fees?", a: "Our comprehensive initial consultation has a fee of PKR 2,000, which is fully redeemable against any treatment booked within 30 days." },
      { q: "Do you offer payment plans?", a: "Yes. We offer flexible instalment options and package plans to make your desired treatments accessible." }
    ]
  },
  {
    category: "Results",
    questions: [
      { q: "When will I see results?", a: "Some treatments, like HydraFacial, offer instant results. Others, like HIFU or PRP, stimulate collagen production and take 2–3 months to show peak results." },
      { q: "Are results permanent?", a: "Aesthetic results vary. Laser hair removal offers permanent reduction, while injectables and skin treatments require maintenance to sustain optimal results." },
      { q: "How do I maintain my results?", a: "We will provide you with a customised medical-grade home skincare regimen to protect your investment and prolong your results." }
    ]
  }
];

export const blogPosts = [
  {
    slug: 'science-behind-hydrafacial',
    title: 'The Science Behind HydraFacial: Why Your Skin Deserves It',
    category: 'Treatments',
    excerpt: 'Discover why this patented vortex technology is the gold standard for immediate skin rejuvenation and hydration without downtime.',
    readTime: '4 min read',
    image: '/images/blog-1.jpg',
    content: `
      <p>In the world of medical aesthetics, few treatments have achieved the cult status of the HydraFacial. It is performed every 15 seconds around the world, but what exactly makes it so revolutionary?</p>
      <p>Unlike traditional microdermabrasion, which uses a gritty surface to sand away the top layer of skin, HydraFacial uses a patented vortex-fusion technology. This essentially acts as a gentle vacuum, simultaneously extracting impurities from deep within your pores while infusing the skin with intense active serums.</p>
      <p>The three-step process—Cleanse + Peel, Extract + Hydrate, and Fuse + Protect—ensures that the skin is not only deeply cleansed but also fortified with antioxidants, peptides, and hyaluronic acid. The result is an immediate, undeniable glow that lasts for days, making it the perfect pre-event treatment.</p>
      <p>At Lumina Aesthetics Lahore, we customise every HydraFacial with specific booster serums tailored to your unique skin concerns, whether that is pigmentation, fine lines, or acne.</p>
    `
  },
  {
    slug: 'laser-hair-removal-guide',
    title: 'Complete Guide to Laser Hair Removal: What to Expect',
    category: 'Guides',
    excerpt: 'Everything you need to know about ditching the razor forever, from pain levels to preparation and expected timelines.',
    readTime: '6 min read',
    image: '/images/blog-2.jpg',
    content: `
      <p>Laser hair removal is one of our most requested procedures, yet many patients come to us with misconceptions about the process. Here is your definitive guide to achieving smooth, hair-free skin.</p>
      <p>The technology works by targeting the melanin (pigment) in the hair follicle. The laser energy converts to heat, safely destroying the follicle's ability to produce hair without damaging the surrounding skin. Because hair grows in different cycles, multiple sessions are required to catch all hairs in their active growth phase.</p>
      <p>Preparation is key. You must avoid sun exposure for at least two weeks prior to your session. We ask patients to shave the area 24 hours before treatment—do not wax or pluck, as the laser needs the root of the hair intact to effectively target the follicle.</p>
      <p>Most patients describe the sensation as a quick snap of a rubber band. Our advanced lasers feature dynamic cooling systems that make the treatment highly tolerable even for sensitive skin.</p>
    `
  },
  {
    slug: 'anti-aging-tips',
    title: '10 Anti-Aging Tips Dermatologists Actually Recommend',
    category: 'Skincare',
    excerpt: 'Cut through the noise of social media trends with these evidence-based strategies for maintaining youthful skin.',
    readTime: '5 min read',
    image: '/images/blog-1.jpg',
    content: `
      <p>With thousands of products claiming to be the fountain of youth, it can be overwhelming to build an effective anti-aging routine. Our medical team breaks down the non-negotiables of skin longevity.</p>
      <p>First and foremost: Sun protection is your best anti-aging defence. In Pakistan, with our high UV index, a broad-spectrum SPF of at least 50, applied daily regardless of the weather, is non-negotiable.</p>
      <p>Secondly, integrate a retinoid into your evening routine. Retinoids (vitamin A derivatives) are the most scientifically proven topical ingredient for stimulating collagen production, accelerating cell turnover, and reducing fine lines.</p>
      <p>Finally, consistency over intensity. Using gentle, scientifically proven ingredients consistently will yield far better long-term results than aggressively exfoliating or constantly switching products. Less is often more when it comes to a medical-grade skincare regimen.</p>
    `
  },
  {
    slug: 'glowing-skin-routine',
    title: 'How to Build a Glowing Skin Routine from Scratch',
    category: 'Skincare',
    excerpt: 'A minimalist, medical-grade approach to achieving that coveted glass skin look naturally.',
    readTime: '4 min read',
    image: '/images/blog-2.jpg',
    content: `
      <p>The secret to glowing skin is not found in a 12-step routine; it is found in a targeted, high-quality regimen that addresses your specific barrier needs.</p>
      <p>Morning routines should focus on protection. Start with a gentle, non-stripping cleanser. Follow with a Vitamin C serum — a potent antioxidant that brightens the complexion and protects against environmental free radicals. Lock it in with a moisturiser suitable for your skin type and your daily SPF.</p>
      <p>Evening routines are for repair. Double cleanse to remove makeup and pollution. Apply your active treatments (like AHAs, BHAs, or Retinol) on alternating nights to prevent barrier damage. Finish with a rich, ceramide-heavy moisturiser to support skin healing while you sleep.</p>
    `
  },
  {
    slug: 'prp-therapy-explained',
    title: 'PRP Therapy Explained: From Blood Draw to Beautiful Skin',
    category: 'Treatments',
    excerpt: 'Demystifying the Vampire Facial and why utilising your body\'s own growth factors is the ultimate regenerative treatment.',
    readTime: '5 min read',
    image: '/images/blog-1.jpg',
    content: `
      <p>Platelet-Rich Plasma (PRP) therapy has revolutionised aesthetic medicine by harnessing the body's natural healing power to rejuvenate the skin.</p>
      <p>The process begins with a simple, standard blood draw. We then place the vial in a centrifuge, rapidly spinning it to separate the red blood cells from the plasma. This liquid gold plasma is incredibly rich in platelets and growth factors.</p>
      <p>When this PRP is micro-needled or injected back into the skin, it signals your body to accelerate collagen and elastin production. This significantly improves skin texture, minimises pore size, reduces fine lines, and diminishes acne scarring.</p>
      <p>Because PRP uses your own biological material, there is absolutely zero risk of allergic reaction, making it one of the safest and most natural regenerative treatments available.</p>
    `
  }
];

export const testimonials = [
  {
    id: 1,
    name: "Sana K.",
    location: "Lahore",
    treatment: "HydraFacial & Laser",
    rating: 5,
    quote: "Walking into Lumina feels like stepping into another world. The attention to detail is unmatched, and my skin has never looked so inherently healthy. I rarely wear foundation anymore.",
    image: "/images/testimonial-1.jpg"
  },
  {
    id: 2,
    name: "Fatima A.",
    location: "DHA, Lahore",
    treatment: "Anti-Aging Protocol",
    rating: 5,
    quote: "Dr. Ayesha is an artist. She does not change how you look; she simply makes you look like the absolute best, most rested version of yourself. True luxury right here in Lahore.",
    image: "/images/testimonial-2.jpg"
  },
  {
    id: 3,
    name: "Ahmed R.",
    location: "Islamabad",
    treatment: "Acne Treatment",
    rating: 5,
    quote: "After years of struggling with adult acne, the team at Lumina finally gave me a solution that worked. Their approach is highly scientific and compassionate.",
    image: null
  },
  {
    id: 4,
    name: "Maryam T.",
    location: "Gulberg, Lahore",
    treatment: "PRP Facial",
    rating: 5,
    quote: "The PRP facial gave me results I did not think were possible without surgery. The clinical environment is immaculate but feels like a private spa.",
    image: "/images/testimonial-1.jpg"
  },
  {
    id: 5,
    name: "Zara S.",
    location: "Clifton, Karachi",
    treatment: "Skin Tightening",
    rating: 5,
    quote: "Incredible experience from the moment you walk through the door. The staff is discreet, professional, and exceptionally skilled at what they do.",
    image: "/images/testimonial-2.jpg"
  }
];
