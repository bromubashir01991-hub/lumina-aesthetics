import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { faqs } from '@/lib/data';
import * as Accordion from '@radix-ui/react-accordion';
import { ChevronDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function FAQs() {
  return (
    <Layout>
      <section className="pt-32 pb-20 bg-secondary border-b border-border">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">Everything You Need to Know</h1>
            <p className="text-muted-foreground font-light text-lg max-w-2xl mx-auto">
              Clear, transparent answers to help you prepare for your Lumina experience.
            </p>
          </FadeIn>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 max-w-3xl">
          <div className="space-y-16">
            {faqs.map((group, idx) => (
              <FadeIn key={group.category} delay={idx * 0.1}>
                <h2 className="font-serif text-3xl mb-8 pb-4 border-b border-border">{group.category}</h2>
                <Accordion.Root type="single" collapsible className="w-full">
                  {group.questions.map((faq, fIdx) => (
                    <Accordion.Item key={fIdx} value={`${group.category}-${fIdx}`} className="border-b border-border">
                      <Accordion.Header className="flex">
                        <Accordion.Trigger className="flex flex-1 items-center justify-between py-6 text-left font-serif text-xl md:text-2xl transition-all hover:text-accent [&[data-state=open]>svg]:rotate-180 [&[data-state=open]]:text-accent outline-none">
                          {faq.q}
                          <ChevronDown className="h-5 w-5 shrink-0 transition-transform duration-300 text-muted-foreground" />
                        </Accordion.Trigger>
                      </Accordion.Header>
                      <Accordion.Content className="overflow-hidden text-muted-foreground font-light text-base leading-relaxed data-[state=closed]:animate-accordion-up data-[state=open]:animate-accordion-down">
                        <div className="pb-6">
                          {faq.a}
                        </div>
                      </Accordion.Content>
                    </Accordion.Item>
                  ))}
                </Accordion.Root>
              </FadeIn>
            ))}
          </div>

          <FadeIn className="mt-20 text-center bg-secondary/50 p-12 border border-border">
            <h3 className="font-serif text-2xl mb-4">Still have questions?</h3>
            <p className="text-muted-foreground font-light mb-8">Our medical concierge is available to assist you.</p>
            <Button href="/contact" variant="outline" className="bg-white">Contact Us</Button>
          </FadeIn>
        </div>
      </section>
    </Layout>
  );
}
