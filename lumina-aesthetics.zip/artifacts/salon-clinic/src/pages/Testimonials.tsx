import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { testimonials } from '@/lib/data';
import { Star, Quote } from 'lucide-react';
import useEmblaCarousel from 'embla-carousel-react';
import { useEffect, useCallback } from 'react';

export default function Testimonials() {
  const [emblaRef, emblaApi] = useEmblaCarousel({ loop: true, align: 'center' });

  const scrollPrev = useCallback(() => {
    if (emblaApi) emblaApi.scrollPrev();
  }, [emblaApi]);

  const scrollNext = useCallback(() => {
    if (emblaApi) emblaApi.scrollNext();
  }, [emblaApi]);

  // Auto scroll
  useEffect(() => {
    if (!emblaApi) return;
    const interval = setInterval(() => {
      emblaApi.scrollNext();
    }, 5000);
    return () => clearInterval(interval);
  }, [emblaApi]);

  return (
    <Layout>
      <section className="pt-32 pb-20 bg-secondary border-b border-border">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">Client Experiences</h1>
            <p className="text-muted-foreground font-light text-lg max-w-2xl mx-auto italic">
              "Our clients' results speak louder than words."
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Featured Carousel */}
      <section className="py-24 bg-background overflow-hidden border-b border-border">
        <div className="container mx-auto px-4">
          <FadeIn className="text-center mb-12">
            <h2 className="font-serif text-3xl">Featured Stories</h2>
          </FadeIn>
          
          <div className="relative max-w-4xl mx-auto">
            <div className="overflow-hidden" ref={emblaRef}>
              <div className="flex">
                {testimonials.slice(0, 3).map((test) => (
                  <div key={test.id} className="flex-[0_0_100%] min-w-0 pl-4 md:pl-8">
                    <div className="bg-card border border-border p-8 md:p-12 text-center relative h-full flex flex-col items-center">
                      <Quote className="absolute top-8 left-8 text-secondary w-16 h-16 -z-10" />
                      <div className="w-20 h-20 rounded-full overflow-hidden bg-secondary mb-6 border-2 border-white shadow-md">
                        {test.image ? (
                          <img src={test.image} alt={test.name} className="w-full h-full object-cover" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center text-accent font-serif text-3xl bg-primary/30">
                            {test.name.charAt(0)}
                          </div>
                        )}
                      </div>
                      <div className="flex items-center gap-1 text-accent mb-6">
                        {[...Array(test.rating)].map((_, i) => (
                          <Star key={i} size={18} fill="currentColor" />
                        ))}
                      </div>
                      <p className="font-serif text-2xl md:text-3xl leading-relaxed mb-8 italic text-foreground max-w-2xl">"{test.quote}"</p>
                      <h4 className="font-sans font-semibold">{test.name}</h4>
                      <p className="text-sm text-muted-foreground">{test.treatment}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Grid */}
      <section className="py-24 bg-secondary/30">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((test, idx) => (
              <FadeIn key={test.id} delay={idx * 0.1}>
                <div className="bg-card p-8 border border-border text-left h-full flex flex-col">
                  <div className="flex items-center gap-1 text-accent mb-4">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} size={14} fill="currentColor" />
                    ))}
                  </div>
                  <p className="font-light leading-relaxed mb-8 flex-1 text-muted-foreground text-sm md:text-base">"{test.quote}"</p>
                  <div className="flex items-center gap-4 mt-auto border-t border-border pt-6">
                    <div className="w-10 h-10 rounded-full overflow-hidden bg-secondary">
                      {test.image ? (
                        <img src={test.image} alt={test.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-accent font-serif text-lg bg-primary/30">
                          {test.name.charAt(0)}
                        </div>
                      )}
                    </div>
                    <div>
                      <h4 className="font-sans font-medium text-sm">{test.name}</h4>
                      <p className="text-xs text-muted-foreground">{test.treatment}</p>
                    </div>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
