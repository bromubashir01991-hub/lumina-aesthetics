import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { services } from '@/lib/data';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';
import * as Icons from 'lucide-react';

export default function Services() {
  return (
    <Layout>
      <section className="pt-32 pb-20 bg-secondary border-b border-border">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">Our Treatments</h1>
            <p className="text-muted-foreground font-light text-lg max-w-2xl mx-auto">
              A comprehensive portfolio of medical-grade aesthetic procedures tailored to your unique skin biology.
            </p>
          </FadeIn>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, idx) => {
              // Dynamically get icon component
              const IconComponent = (Icons as any)[service.icon] || Icons.Sparkles;

              return (
                <FadeIn key={service.id} delay={idx * 0.05}>
                  <Link href={`/services/${service.slug}`} className="group block h-full">
                    <div className="bg-card p-8 border border-border h-full transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] hover:border-accent/30 relative overflow-hidden flex flex-col">
                      <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-6 text-foreground group-hover:text-accent group-hover:bg-primary/20 transition-colors">
                        <IconComponent size={24} strokeWidth={1.5} />
                      </div>
                      
                      <h3 className="font-serif text-2xl mb-3">{service.name}</h3>
                      <p className="text-muted-foreground font-light mb-6 flex-1">{service.shortDesc}</p>
                      
                      <div className="pt-6 border-t border-border mt-auto flex items-center justify-between">
                        <div className="flex flex-col text-sm">
                          <span className="text-muted-foreground font-light">{service.duration}</span>
                          <span className="font-medium text-accent">{service.price}</span>
                        </div>
                        <div className="w-10 h-10 rounded-full border border-border flex items-center justify-center group-hover:bg-accent group-hover:border-accent group-hover:text-white transition-all">
                          <ArrowRight size={16} />
                        </div>
                      </div>
                    </div>
                  </Link>
                </FadeIn>
              );
            })}
          </div>
        </div>
      </section>
    </Layout>
  );
}
