import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { services } from '@/lib/data';
import { useRoute } from 'wouter';
import { Button } from '@/components/ui/button';
import { Clock, Tag, CheckCircle2 } from 'lucide-react';
import * as Icons from 'lucide-react';

export default function ServiceDetail() {
  const [, params] = useRoute('/services/:slug');
  const serviceSlug = params?.slug;
  const service = services.find(s => s.slug === serviceSlug);

  if (!service) {
    return (
      <Layout>
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-serif text-4xl mb-4">Treatment Not Found</h1>
            <Button href="/services" variant="outline">Back to Services</Button>
          </div>
        </div>
      </Layout>
    );
  }

  const IconComponent = (Icons as any)[service.icon] || Icons.Sparkles;

  // Mock detailed content for the specific service
  const benefits = [
    "Immediate, visible results with zero downtime",
    "Deeply cleanses, exfoliates, and extracts impurities",
    "Infuses skin with potent antioxidants and hyaluronic acid",
    "Customizable to address specific skin concerns"
  ];

  const process = [
    { step: "1", title: "Cleanse & Peel", desc: "Uncovers a new layer of skin with gentle exfoliation and relaxing resurfacing." },
    { step: "2", title: "Extract & Hydrate", desc: "Removes debris from pores with painless suction. Nourishes with intense moisturizers." },
    { step: "3", title: "Fuse & Protect", desc: "Saturates the skin's surface with antioxidants and peptides to maximize your glow." }
  ];

  return (
    <Layout>
      {/* Hero */}
      <section className="pt-32 pb-20 bg-secondary border-b border-border relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/2 h-full opacity-10 bg-[url('/images/treatment-1.jpg')] bg-cover bg-center" />
        <div className="container mx-auto px-4 relative z-10">
          <FadeIn>
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center text-accent shadow-sm">
                <IconComponent size={32} strokeWidth={1.5} />
              </div>
              <div className="flex items-center gap-4 text-sm font-medium">
                <span className="flex items-center gap-1 text-muted-foreground bg-white px-3 py-1 rounded-full"><Clock size={14} /> {service.duration}</span>
                <span className="flex items-center gap-1 text-accent bg-white px-3 py-1 rounded-full"><Tag size={14} /> {service.price}</span>
              </div>
            </div>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">{service.name}</h1>
            <p className="text-muted-foreground font-light text-xl max-w-2xl">
              {service.shortDesc}
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-3 gap-16">
            
            {/* Left Col - Info */}
            <div className="lg:col-span-2 space-y-16">
              <FadeIn>
                <h2 className="font-serif text-3xl mb-6">Overview</h2>
                <div className="prose prose-p:text-muted-foreground prose-p:font-light prose-p:leading-relaxed max-w-none">
                  <p>
                    Experience the pinnacle of skin rejuvenation with our advanced {service.name} protocol. 
                    This treatment is not just a procedure; it is a transformative medical-grade therapy designed 
                    to optimize your skin's health at a cellular level.
                  </p>
                  <p>
                    Conducted by our highly trained specialists in a pristine, relaxing environment, this treatment 
                    addresses your unique concerns—whether that's fine lines, uneven texture, congestion, or dullness. 
                    We utilize only industry-leading, FDA-approved technology to ensure safety, efficacy, and 
                    unparalleled results.
                  </p>
                </div>
              </FadeIn>

              <FadeIn>
                <h2 className="font-serif text-3xl mb-6">Key Benefits</h2>
                <div className="grid sm:grid-cols-2 gap-4">
                  {benefits.map((benefit, i) => (
                    <div key={i} className="flex items-start gap-3 p-4 bg-secondary/30 rounded-sm">
                      <CheckCircle2 className="text-accent shrink-0 mt-0.5" size={20} />
                      <span className="text-muted-foreground font-light">{benefit}</span>
                    </div>
                  ))}
                </div>
              </FadeIn>

              <FadeIn>
                <h2 className="font-serif text-3xl mb-6">The Process</h2>
                <div className="space-y-8">
                  {process.map((p, i) => (
                    <div key={i} className="flex gap-6 relative">
                      {i !== process.length -1 && (
                        <div className="absolute left-6 top-14 bottom-[-2rem] w-px bg-border" />
                      )}
                      <div className="w-12 h-12 rounded-full bg-primary/20 text-accent font-serif text-2xl flex items-center justify-center shrink-0 border border-primary/30 z-10">
                        {p.step}
                      </div>
                      <div>
                        <h3 className="font-serif text-xl mb-2">{p.title}</h3>
                        <p className="text-muted-foreground font-light">{p.desc}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </FadeIn>
            </div>

            {/* Right Col - Sticky Booking Card */}
            <div className="lg:col-span-1">
              <div className="sticky top-32 bg-card border border-border p-8 shadow-xl text-center">
                <h3 className="font-serif text-2xl mb-4">Book This Treatment</h3>
                <p className="text-muted-foreground font-light text-sm mb-8">
                  Schedule your consultation today. Our specialists will assess if {service.name} is right for you.
                </p>
                <Button href="/book" variant="gold" className="w-full mb-4">
                  Book Appointment
                </Button>
                <div className="text-xs text-muted-foreground flex items-center justify-center gap-2">
                  <Icons.ShieldCheck size={14} /> Doctor Supervised Treatment
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>
    </Layout>
  );
}
