import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { blogPosts } from '@/lib/data';
import { useRoute, Link } from 'wouter';
import { ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function BlogDetail() {
  const [, params] = useRoute('/blog/:slug');
  const postSlug = params?.slug;
  const post = blogPosts.find(p => p.slug === postSlug);

  if (!post) {
    return (
      <Layout>
        <div className="min-h-[60vh] flex items-center justify-center">
          <div className="text-center">
            <h1 className="font-serif text-4xl mb-4">Article Not Found</h1>
            <Button href="/blog" variant="outline">Back to Journal</Button>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <article className="pt-32 pb-24 bg-background">
        <div className="container mx-auto px-4 max-w-3xl">
          <FadeIn>
            <Link href="/blog" className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-accent mb-8 transition-colors">
              <ArrowLeft size={16} /> Back to Journal
            </Link>
            
            <div className="flex items-center gap-4 mb-6 text-xs font-semibold uppercase tracking-widest text-accent">
              <span>{post.category}</span>
              <span className="w-1 h-1 rounded-full bg-border" />
              <span>{post.readTime}</span>
            </div>

            <h1 className="font-serif text-4xl md:text-6xl mb-8 leading-[1.1]">{post.title}</h1>
            
            <div className="aspect-[21/9] w-full overflow-hidden mb-12">
              <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
            </div>

            <div 
              className="prose prose-lg prose-p:font-light prose-p:text-muted-foreground prose-headings:font-serif prose-a:text-accent hover:prose-a:text-[#b88c67] max-w-none prose-p:leading-relaxed"
              dangerouslySetInnerHTML={{ __html: post.content }}
            />

            <div className="mt-16 pt-8 border-t border-border flex justify-center">
              <Button href="/book" variant="gold" size="lg">
                Book a Consultation
              </Button>
            </div>
          </FadeIn>
        </div>
      </article>
    </Layout>
  );
}
