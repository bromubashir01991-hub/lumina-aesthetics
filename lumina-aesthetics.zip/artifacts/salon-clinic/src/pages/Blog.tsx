import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { blogPosts } from '@/lib/data';
import { Link } from 'wouter';
import { ArrowRight } from 'lucide-react';

export default function Blog() {
  return (
    <Layout>
      <section className="pt-32 pb-20 bg-secondary border-b border-border">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">The Journal</h1>
            <p className="text-muted-foreground font-light text-lg max-w-2xl mx-auto">
              Expert insights, clinical skincare advice, and aesthetic education from our medical team.
            </p>
          </FadeIn>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          
          {/* Featured Post */}
          {blogPosts.length > 0 && (
            <FadeIn className="mb-20">
              <Link href={`/blog/${blogPosts[0].slug}`} className="group block">
                <div className="grid lg:grid-cols-2 gap-8 lg:gap-16 items-center">
                  <div className="aspect-[4/3] lg:aspect-square overflow-hidden relative">
                    <img 
                      src={blogPosts[0].image} 
                      alt={blogPosts[0].title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                  </div>
                  <div className="max-w-xl">
                    <div className="flex items-center gap-4 mb-4 text-xs font-semibold uppercase tracking-widest text-accent">
                      <span>{blogPosts[0].category}</span>
                      <span className="w-1 h-1 rounded-full bg-border" />
                      <span>{blogPosts[0].readTime}</span>
                    </div>
                    <h2 className="font-serif text-4xl lg:text-5xl mb-6 group-hover:text-accent transition-colors leading-tight">{blogPosts[0].title}</h2>
                    <p className="text-muted-foreground font-light text-lg mb-8 leading-relaxed">{blogPosts[0].excerpt}</p>
                    <span className="flex items-center gap-2 font-medium uppercase tracking-wider text-sm border-b border-foreground pb-1 inline-flex group-hover:border-accent group-hover:text-accent transition-colors">
                      Read Article <ArrowRight size={16} />
                    </span>
                  </div>
                </div>
              </Link>
            </FadeIn>
          )}

          {/* Grid Posts */}
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-x-8 gap-y-16">
            {blogPosts.slice(1).map((post, idx) => (
              <FadeIn key={post.slug} delay={idx * 0.1}>
                <Link href={`/blog/${post.slug}`} className="group block h-full flex flex-col">
                  <div className="aspect-[4/3] overflow-hidden mb-6 relative">
                    <img 
                      src={post.image} 
                      alt={post.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute top-4 left-4 bg-background/90 backdrop-blur text-xs font-semibold px-3 py-1 uppercase tracking-wider text-accent">
                      {post.category}
                    </div>
                  </div>
                  <h3 className="font-serif text-2xl mb-3 group-hover:text-accent transition-colors">{post.title}</h3>
                  <p className="text-muted-foreground font-light mb-6 flex-1 line-clamp-3">{post.excerpt}</p>
                  <div className="flex items-center justify-between text-sm pt-4 border-t border-border mt-auto">
                    <span className="text-muted-foreground">{post.readTime}</span>
                    <span className="font-medium group-hover:text-accent transition-colors">Read →</span>
                  </div>
                </Link>
              </FadeIn>
            ))}
          </div>

        </div>
      </section>
    </Layout>
  );
}
