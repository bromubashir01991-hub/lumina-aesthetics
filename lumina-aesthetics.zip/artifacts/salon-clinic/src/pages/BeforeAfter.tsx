import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { useState, useRef } from 'react';

// Custom Slider Component
function CompareSlider({ beforeImg, afterImg, label }: { beforeImg: string, afterImg: string, label: string }) {
  const [sliderPosition, setSliderPosition] = useState(50);
  const containerRef = useRef<HTMLDivElement>(null);

  const handleMove = (clientX: number) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const pos = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(pos);
  };

  const handleMouseMove = (e: React.MouseEvent) => handleMove(e.clientX);
  const handleTouchMove = (e: React.TouchEvent) => handleMove(e.touches[0].clientX);

  return (
    <div className="flex flex-col gap-4">
      <div 
        ref={containerRef}
        className="relative w-full aspect-[4/3] overflow-hidden rounded-sm cursor-ew-resize select-none"
        onMouseMove={handleMouseMove}
        onTouchMove={handleTouchMove}
      >
        {/* After Image (Background) */}
        <div className="absolute inset-0 bg-secondary flex items-center justify-center">
          {afterImg === 'placeholder' ? (
             // Placeholder for After: smooth, glowing gradient
             <div className="w-full h-full bg-gradient-to-br from-[#F6D8CB] to-[#FCFAF8]" />
          ) : (
            <img src={afterImg} alt="After" className="w-full h-full object-cover" />
          )}
          <span className="absolute bottom-4 right-4 bg-white/80 backdrop-blur px-3 py-1 text-xs font-semibold uppercase tracking-widest z-0">After</span>
        </div>

        {/* Before Image (Foreground, clipped) */}
        <div 
          className="absolute inset-0 bg-primary flex items-center justify-center border-r-2 border-white"
          style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
        >
          {beforeImg === 'placeholder' ? (
             // Placeholder for Before: duller, textured gradient
             <div className="w-full h-full bg-[#E5D5CD] bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0IiBoZWlnaHQ9IjQiPgo8cmVjdCB3aWR0aD0iNCIgaGVpZ2h0PSI0IiBmaWxsPSIjZmZmIiBmaWxsLW9wYWNpdHk9IjAiLz4KPGNpcmNsZSBjeD0iMSIgY3k9IjEiIHI9IjEiIGZpbGw9IiMwMDAiIGZpbGwtb3BhY2l0eT0iMC4wNSIvPgo8L3N2Zz4=')] mix-blend-multiply" />
          ) : (
            <img src={beforeImg} alt="Before" className="w-full h-full object-cover" />
          )}
          <span className="absolute bottom-4 left-4 bg-white/80 backdrop-blur px-3 py-1 text-xs font-semibold uppercase tracking-widest">Before</span>
        </div>

        {/* Slider Handle */}
        <div 
          className="absolute top-0 bottom-0 w-1 bg-white flex items-center justify-center pointer-events-none shadow-[0_0_10px_rgba(0,0,0,0.3)]"
          style={{ left: `${sliderPosition}%`, transform: 'translateX(-50%)' }}
        >
          <div className="w-8 h-8 bg-white rounded-full flex items-center justify-center shadow-md">
            <div className="flex gap-1">
              <div className="w-0.5 h-3 bg-muted-foreground/50" />
              <div className="w-0.5 h-3 bg-muted-foreground/50" />
            </div>
          </div>
        </div>
      </div>
      <h3 className="font-serif text-xl text-center">{label}</h3>
    </div>
  );
}

export default function BeforeAfter() {
  const comparisons = [
    { label: "HydraFacial Glow", quote: "My skin went from dull and congested to glass-like in 45 minutes.", time: "Immediate Result" },
    { label: "Acne Treatment Protocol", quote: "Finally, a solution that worked. My confidence is completely restored.", time: "12 Weeks" },
    { label: "Pigmentation Correction", quote: "The sun damage I've had for years is practically erased.", time: "3 Sessions" },
    { label: "Skin Tightening", quote: "A subtle, natural lift without surgery. Exactly what I wanted.", time: "8 Weeks" },
  ];

  return (
    <Layout>
      <section className="pt-32 pb-20 bg-secondary border-b border-border">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">Transformations That Speak</h1>
            <p className="text-muted-foreground font-light text-lg max-w-2xl mx-auto">
              Real results from real patients. Drag the slider to reveal the Lumina difference.
            </p>
          </FadeIn>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid md:grid-cols-2 gap-16">
            {comparisons.map((comp, idx) => (
              <FadeIn key={idx} delay={idx * 0.1}>
                <CompareSlider 
                  beforeImg="placeholder" 
                  afterImg="placeholder" 
                  label={comp.label} 
                />
                <div className="text-center mt-6">
                  <p className="italic text-muted-foreground font-light mb-2">"{comp.quote}"</p>
                  <p className="text-xs font-semibold tracking-widest uppercase text-accent">{comp.time}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
}
