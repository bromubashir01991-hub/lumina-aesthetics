import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { MapPin, Phone, Mail, Clock, Instagram, Facebook, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Contact() {
  return (
    <Layout>
      <section className="pt-32 pb-20 bg-secondary border-b border-border">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">Contact Us</h1>
            <p className="text-muted-foreground font-light text-lg max-w-2xl mx-auto">
              We are here to answer your questions and assist with your booking.
            </p>
          </FadeIn>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 max-w-6xl mx-auto">
            
            {/* Left Col - Details */}
            <FadeIn>
              <h2 className="font-serif text-3xl mb-8">Get in Touch</h2>
              
              <div className="space-y-8 mb-12">
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center text-accent shrink-0">
                    <Phone size={20} />
                  </div>
                  <div>
                    <h4 className="font-sans font-medium mb-1">Phone</h4>
                    <p className="text-muted-foreground font-light">+92 42 3576 8800</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center text-accent shrink-0">
                    <Mail size={20} />
                  </div>
                  <div>
                    <h4 className="font-sans font-medium mb-1">Email</h4>
                    <p className="text-muted-foreground font-light">hello@luminaaesthetics.pk</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center text-accent shrink-0">
                    <MapPin size={20} />
                  </div>
                  <div>
                    <h4 className="font-sans font-medium mb-1">Location</h4>
                    <p className="text-muted-foreground font-light">12-A Main Gulberg III<br/>Lahore, Punjab, Pakistan</p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-primary/20 rounded-full flex items-center justify-center text-accent shrink-0">
                    <Clock size={20} />
                  </div>
                  <div>
                    <h4 className="font-sans font-medium mb-1">Hours</h4>
                    <p className="text-muted-foreground font-light">Mon–Sat: 10:00 AM – 8:00 PM<br/>Sun: By appointment only</p>
                  </div>
                </div>
              </div>

              <h4 className="font-serif text-xl mb-4">Connect With Us</h4>
              <div className="flex items-center gap-4">
                <a href="#" className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-accent hover:text-white hover:border-accent transition-all">
                  <Instagram size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-accent hover:text-white hover:border-accent transition-all">
                  <Facebook size={18} />
                </a>
                <a href="#" className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-[#25D366] hover:text-white hover:border-[#25D366] transition-all">
                  <MessageCircle size={18} />
                </a>
              </div>
            </FadeIn>

            {/* Right Col - Map & Form */}
            <FadeIn direction="left" className="space-y-8">
              {/* Map Placeholder */}
              <a
                href="https://maps.google.com/?q=Gulberg+III,+Lahore,+Pakistan"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full aspect-video bg-secondary border border-border rounded-sm relative overflow-hidden flex flex-col items-center justify-center group cursor-pointer no-underline"
              >
                {/* Decorative grid pattern mimicking a map */}
                <svg className="absolute inset-0 w-full h-full opacity-20" xmlns="http://www.w3.org/2000/svg">
                  <defs>
                    <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
                      <path d="M 40 0 L 0 0 0 40" fill="none" stroke="#C9A27E" strokeWidth="0.5"/>
                    </pattern>
                  </defs>
                  <rect width="100%" height="100%" fill="url(#grid)" />
                  {/* Road lines */}
                  <line x1="0" y1="50%" x2="100%" y2="50%" stroke="#C9A27E" strokeWidth="2" opacity="0.4"/>
                  <line x1="35%" y1="0" x2="35%" y2="100%" stroke="#C9A27E" strokeWidth="2" opacity="0.4"/>
                  <line x1="70%" y1="0" x2="70%" y2="100%" stroke="#C9A27E" strokeWidth="1" opacity="0.25"/>
                  <line x1="0" y1="25%" x2="100%" y2="25%" stroke="#C9A27E" strokeWidth="1" opacity="0.25"/>
                  <line x1="0" y1="75%" x2="100%" y2="75%" stroke="#C9A27E" strokeWidth="1" opacity="0.25"/>
                </svg>
                <div className="relative z-10 flex flex-col items-center gap-3">
                  <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center shadow-lg group-hover:scale-110 group-hover:text-accent transition-all duration-300 text-accent">
                    <MapPin size={26} fill="currentColor" fillOpacity={0.15} />
                  </div>
                  <div className="text-center">
                    <p className="font-sans font-semibold text-sm text-foreground">12-A Main Gulberg III</p>
                    <p className="font-sans text-xs text-muted-foreground">Lahore, Punjab, Pakistan</p>
                  </div>
                  <span className="text-xs font-medium text-accent border border-accent/30 px-3 py-1 rounded-full bg-white/60 group-hover:bg-accent group-hover:text-white transition-all duration-300">
                    Open in Google Maps
                  </span>
                </div>
              </a>

              {/* Form */}
              <form className="bg-card border border-border p-8" onSubmit={(e) => e.preventDefault()}>
                <h3 className="font-serif text-2xl mb-6">Send a Message</h3>
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Name</label>
                      <input type="text" className="w-full h-12 bg-background border border-border px-4 focus:outline-none focus:border-accent transition-colors rounded-sm" placeholder="Your name" />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Phone</label>
                      <input type="tel" className="w-full h-12 bg-background border border-border px-4 focus:outline-none focus:border-accent transition-colors rounded-sm" placeholder="Your phone" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Email</label>
                    <input type="email" className="w-full h-12 bg-background border border-border px-4 focus:outline-none focus:border-accent transition-colors rounded-sm" placeholder="Your email" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Message</label>
                    <textarea className="w-full min-h-[120px] bg-background border border-border p-4 focus:outline-none focus:border-accent transition-colors rounded-sm resize-none" placeholder="How can we help you?"></textarea>
                  </div>
                  <Button type="submit" variant="primary" className="w-full mt-2">Send Message</Button>
                </div>
              </form>
            </FadeIn>

          </div>
        </div>
      </section>
    </Layout>
  );
}
