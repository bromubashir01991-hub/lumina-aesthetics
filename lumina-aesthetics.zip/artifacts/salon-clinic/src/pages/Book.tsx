import { useState } from 'react';
import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { services } from '@/lib/data';
import { Button } from '@/components/ui/button';
import { CheckCircle2, ChevronRight, ChevronLeft } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function Book() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    treatment: '',
    date: '',
    time: '',
    name: '',
    email: '',
    phone: '',
    notes: ''
  });

  const nextStep = () => setStep(s => Math.min(s + 1, 4));
  const prevStep = () => setStep(s => Math.max(s - 1, 1));

  const isStepValid = () => {
    if (step === 1) return formData.treatment !== '';
    if (step === 2) return formData.date !== '' && formData.time !== '';
    if (step === 3) return formData.name !== '' && formData.email !== '' && formData.phone !== '';
    return true;
  };

  const handleComplete = (e: React.FormEvent) => {
    e.preventDefault();
    nextStep(); // Move to success step 4
  };

  return (
    <Layout>
      <section className="pt-32 pb-20 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,rgba(255,255,255,0.4)_0%,transparent_100%)]" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-4">Begin Your Transformation</h1>
            <p className="text-foreground/80 font-light text-lg">Secure your consultation securely and discreetly.</p>
          </FadeIn>
        </div>
      </section>

      <section className="py-12 bg-background min-h-[60vh]">
        <div className="container mx-auto px-4 max-w-4xl">
          
          {/* Progress Indicator */}
          {step < 4 && (
            <div className="mb-12">
              <div className="flex justify-between relative mb-2">
                <div className="absolute top-1/2 left-0 w-full h-[1px] bg-border -z-10 -translate-y-1/2" />
                <div 
                  className="absolute top-1/2 left-0 h-[2px] bg-accent -z-10 -translate-y-1/2 transition-all duration-500" 
                  style={{ width: `${((step - 1) / 2) * 100}%` }}
                />
                
                {[1, 2, 3].map((num) => (
                  <div 
                    key={num} 
                    className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-colors border bg-background",
                      step >= num ? "border-accent text-accent" : "border-border text-muted-foreground",
                      step === num && "ring-4 ring-primary bg-primary text-foreground"
                    )}
                  >
                    {step > num ? <CheckCircle2 size={16} /> : num}
                  </div>
                ))}
              </div>
              <div className="flex justify-between text-xs uppercase tracking-wider text-muted-foreground px-2">
                <span>Treatment</span>
                <span>Schedule</span>
                <span>Details</span>
              </div>
            </div>
          )}

          <div className="bg-card border border-border shadow-xl p-6 md:p-12 relative overflow-hidden">
            {/* Step 1: Treatment */}
            {step === 1 && (
              <FadeIn direction="none" duration={0.3}>
                <h2 className="font-serif text-3xl mb-8">Select a Treatment</h2>
                <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4 mb-8">
                  {services.map(service => (
                    <div 
                      key={service.id}
                      onClick={() => setFormData({...formData, treatment: service.name})}
                      className={cn(
                        "p-4 border rounded-sm cursor-pointer transition-all hover:border-accent",
                        formData.treatment === service.name 
                          ? "border-accent bg-primary/10 shadow-[0_0_0_1px_hsl(var(--accent))]" 
                          : "border-border bg-background"
                      )}
                    >
                      <h4 className="font-serif text-lg mb-1">{service.name}</h4>
                      <p className="text-xs text-muted-foreground">{service.duration}</p>
                    </div>
                  ))}
                  <div 
                      onClick={() => setFormData({...formData, treatment: 'Consultation Only'})}
                      className={cn(
                        "p-4 border rounded-sm cursor-pointer transition-all hover:border-accent",
                        formData.treatment === 'Consultation Only'
                          ? "border-accent bg-primary/10 shadow-[0_0_0_1px_hsl(var(--accent))]" 
                          : "border-border bg-background"
                      )}
                    >
                      <h4 className="font-serif text-lg mb-1">Consultation Only</h4>
                      <p className="text-xs text-muted-foreground">30 mins</p>
                    </div>
                </div>
              </FadeIn>
            )}

            {/* Step 2: Date & Time */}
            {step === 2 && (
              <FadeIn direction="none" duration={0.3}>
                <h2 className="font-serif text-3xl mb-8">Choose Date & Time</h2>
                <div className="grid md:grid-cols-2 gap-8 mb-8">
                  <div>
                    <label className="text-sm font-medium mb-3 block">Preferred Date (Example mock)</label>
                    <div className="grid grid-cols-4 gap-2">
                      {['12', '13', '14', '15', '18', '19', '20', '21'].map(day => (
                        <div 
                          key={day}
                          onClick={() => setFormData({...formData, date: `Oct ${day}`})}
                          className={cn(
                            "aspect-square flex flex-col items-center justify-center border rounded-sm cursor-pointer hover:border-accent",
                            formData.date === `Oct ${day}` ? "border-accent bg-accent text-white" : "border-border bg-background"
                          )}
                        >
                          <span className="text-xs opacity-70">Oct</span>
                          <span className="font-serif text-lg">{day}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-3 block">Preferred Time</label>
                    <div className="grid grid-cols-2 gap-3">
                      {['09:00 AM', '10:30 AM', '01:00 PM', '02:30 PM', '04:00 PM', '05:30 PM'].map(time => (
                        <div 
                          key={time}
                          onClick={() => setFormData({...formData, time})}
                          className={cn(
                            "py-3 text-center border rounded-sm cursor-pointer hover:border-accent text-sm",
                            formData.time === time ? "border-accent bg-primary/20 text-accent font-medium" : "border-border bg-background"
                          )}
                        >
                          {time}
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </FadeIn>
            )}

            {/* Step 3: Details */}
            {step === 3 && (
              <FadeIn direction="none" duration={0.3}>
                <h2 className="font-serif text-3xl mb-2">Your Details</h2>
                <p className="text-muted-foreground text-sm mb-8">Please provide your contact information to finalize the booking.</p>
                <form id="booking-form" onSubmit={handleComplete} className="space-y-6 mb-8">
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Full Name *</label>
                      <input 
                        required
                        type="text" 
                        value={formData.name}
                        onChange={e => setFormData({...formData, name: e.target.value})}
                        className="w-full h-12 bg-background border border-border px-4 focus:outline-none focus:border-accent rounded-sm" 
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium text-foreground">Phone Number *</label>
                      <input 
                        required
                        type="tel" 
                        value={formData.phone}
                        onChange={e => setFormData({...formData, phone: e.target.value})}
                        className="w-full h-12 bg-background border border-border px-4 focus:outline-none focus:border-accent rounded-sm" 
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Email Address *</label>
                    <input 
                      required
                      type="email" 
                      value={formData.email}
                      onChange={e => setFormData({...formData, email: e.target.value})}
                      className="w-full h-12 bg-background border border-border px-4 focus:outline-none focus:border-accent rounded-sm" 
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium text-foreground">Additional Notes (Optional)</label>
                    <textarea 
                      value={formData.notes}
                      onChange={e => setFormData({...formData, notes: e.target.value})}
                      className="w-full h-24 bg-background border border-border p-4 focus:outline-none focus:border-accent rounded-sm resize-none" 
                    />
                  </div>
                </form>
              </FadeIn>
            )}

            {/* Step 4: Success */}
            {step === 4 && (
              <FadeIn direction="up" className="text-center py-12">
                <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 size={40} />
                </div>
                <h2 className="font-serif text-4xl mb-4">Request Received</h2>
                <p className="text-muted-foreground font-light mb-8 max-w-md mx-auto">
                  Thank you, {formData.name}. We have received your booking request for {formData.treatment} on {formData.date} at {formData.time}. Our medical concierge will contact you shortly to confirm your appointment.
                </p>
                <Button href="/" variant="outline">Return Home</Button>
              </FadeIn>
            )}

            {/* Navigation Buttons */}
            {step < 4 && (
              <div className="flex justify-between items-center pt-8 border-t border-border mt-8">
                {step > 1 ? (
                  <Button type="button" variant="ghost" onClick={prevStep} className="gap-2 px-0">
                    <ChevronLeft size={16} /> Back
                  </Button>
                ) : <div />}
                
                {step < 3 ? (
                  <Button 
                    type="button" 
                    variant="primary" 
                    onClick={nextStep} 
                    disabled={!isStepValid()}
                    className="gap-2"
                  >
                    Continue <ChevronRight size={16} />
                  </Button>
                ) : (
                  <Button 
                    type="submit" 
                    form="booking-form"
                    variant="gold" 
                    disabled={!isStepValid()}
                  >
                    Confirm Booking
                  </Button>
                )}
              </div>
            )}
          </div>
        </div>
      </section>
    </Layout>
  );
}
