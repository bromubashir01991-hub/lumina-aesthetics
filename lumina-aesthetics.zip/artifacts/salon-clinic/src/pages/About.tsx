import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { team } from '@/lib/data';
import { Award, ShieldCheck, Heart, Sparkles } from 'lucide-react';

export default function About() {
  return (
    <Layout>
      {/* Hero Banner */}
      <section className="pt-32 pb-20 bg-secondary border-b border-border">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">Our Story</h1>
            <p className="text-muted-foreground font-light text-lg max-w-2xl mx-auto">
              Redefining aesthetic medicine through science, precision, and an unwavering commitment to natural beauty.
            </p>
          </FadeIn>
        </div>
      </section>

      {/* Story & Philosophy */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <FadeIn>
              <h2 className="font-serif text-4xl mb-6">Where Medical Science Meets <span className="italic text-accent">Luxury Aesthetics</span></h2>
              <div className="space-y-6 text-muted-foreground font-light leading-relaxed">
                <p>
                  Founded in 2014 by Dr. Ayesha Malik, Lumina Aesthetics was born from a singular vision: to create a space where clinical excellence and luxurious self-care coexist perfectly in the heart of Lahore.
                </p>
                <p>
                  We noticed a gap in the aesthetic industry. Clinics were either overly medical and sterile, lacking in comfort and discretion, or they were beautiful spas that lacked the rigorous scientific backing needed for truly transformative results.
                </p>
                <p>
                  At Lumina, we bridge that gap. Every treatment protocol is meticulously designed by qualified medical professionals using the world's most advanced, internationally certified technology. Yet, the experience of receiving these treatments feels like visiting a private luxury medical spa — unhurried, deeply relaxing, and exquisitely tailored to you.
                </p>
              </div>
            </FadeIn>
            <FadeIn direction="left">
              <div className="grid grid-cols-2 gap-4">
                <img src="/images/treatment-1.jpg" alt="Treatment" className="w-full aspect-square object-cover" />
                <img src="/images/clinic-interior.jpg" alt="Interior" className="w-full aspect-square object-cover mt-8" />
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-24 bg-primary/20">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-8">
            <FadeIn delay={0.1}>
              <div className="bg-card p-12 h-full border border-border text-center">
                <ShieldCheck className="w-12 h-12 text-accent mx-auto mb-6" strokeWidth={1.5} />
                <h3 className="font-serif text-3xl mb-4">Our Mission</h3>
                <p className="text-muted-foreground font-light leading-relaxed">
                  To provide evidence-based, doctor-supervised aesthetic treatments that safely and effectively restore confidence, honor individual anatomy, and enhance natural beauty without drastically altering one's appearance.
                </p>
              </div>
            </FadeIn>
            <FadeIn delay={0.2}>
              <div className="bg-card p-12 h-full border border-border text-center">
                <Sparkles className="w-12 h-12 text-accent mx-auto mb-6" strokeWidth={1.5} />
                <h3 className="font-serif text-3xl mb-4">Our Vision</h3>
                <p className="text-muted-foreground font-light leading-relaxed">
                  To be the globally recognized standard for luxury aesthetic medicine, pioneering techniques that blur the line between clinical intervention and natural aging, setting a new benchmark for patient care and discretion.
                </p>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* Meet the Team */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <FadeIn className="text-center mb-16">
            <h2 className="font-serif text-4xl md:text-5xl mb-4">Our Specialists</h2>
            <p className="text-muted-foreground font-light max-w-2xl mx-auto">
              A curated team of industry-leading medical professionals dedicated to your care.
            </p>
          </FadeIn>

          <div className="grid md:grid-cols-3 gap-8">
            {team.map((member, idx) => (
              <FadeIn key={idx} delay={idx * 0.1}>
                <div className="group">
                  <div className="aspect-[3/4] overflow-hidden mb-6 bg-secondary relative">
                    <img 
                      src={member.image} 
                      alt={member.name} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                      onError={(e) => {
                        // Fallback for missing images
                        e.currentTarget.style.display = 'none';
                        e.currentTarget.parentElement!.classList.add('flex', 'items-center', 'justify-center', 'text-2xl', 'font-serif', 'text-muted-foreground');
                        e.currentTarget.parentElement!.innerHTML = member.name.charAt(0);
                      }}
                    />
                  </div>
                  <h3 className="font-serif text-2xl mb-1">{member.name}</h3>
                  <div className="text-accent text-sm font-medium mb-1 uppercase tracking-wider">{member.role}</div>
                  <div className="text-xs text-muted-foreground mb-4">{member.credentials}</div>
                  <p className="text-muted-foreground font-light text-sm leading-relaxed">{member.bio}</p>
                </div>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* Brand Promise Strip */}
      <section className="py-20 bg-foreground text-background text-center">
        <div className="container mx-auto px-4">
          <FadeIn>
            <Award className="w-12 h-12 text-accent mx-auto mb-6" strokeWidth={1} />
            <h2 className="font-serif text-3xl md:text-5xl italic font-light tracking-wide">
              Every treatment. Every patient. Perfected.
            </h2>
          </FadeIn>
        </div>
      </section>
    </Layout>
  );
}
