import { useState } from 'react';
import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { motion, AnimatePresence } from 'framer-motion';
import { X, ZoomIn } from 'lucide-react';

export default function Gallery() {
  const [filter, setFilter] = useState('All');
  const [lightboxImg, setLightboxImg] = useState<string | null>(null);

  const filters = ['All', 'Clinic', 'Treatments', 'Results'];

  const images = [
    { id: 1, src: '/images/clinic-interior.jpg', category: 'Clinic', alt: 'Clinic Interior' },
    { id: 2, src: '/images/treatment-1.jpg', category: 'Treatments', alt: 'Facial Treatment' },
    { id: 3, src: '/images/treatment-2.jpg', category: 'Treatments', alt: 'Laser Treatment' },
    { id: 4, src: '/images/blog-2.jpg', category: 'Results', alt: 'Glowing Skin Result' },
    { id: 5, src: '/images/doctor-1.jpg', category: 'Clinic', alt: 'Doctor consultation' },
    { id: 6, src: '/images/testimonial-1.jpg', category: 'Results', alt: 'Client Result' },
    { id: 7, src: '/images/blog-1.jpg', category: 'Treatments', alt: 'Skincare treatment' },
    { id: 8, src: '/images/testimonial-2.jpg', category: 'Results', alt: 'Client Result' },
  ];

  const filteredImages = filter === 'All' ? images : images.filter(img => img.category === filter);

  return (
    <Layout>
      <section className="pt-32 pb-20 bg-secondary border-b border-border">
        <div className="container mx-auto px-4 text-center">
          <FadeIn>
            <h1 className="font-serif text-5xl md:text-7xl mb-6">Gallery</h1>
            <p className="text-muted-foreground font-light text-lg max-w-2xl mx-auto mb-10">
              A glimpse into the Lumina experience.
            </p>

            <div className="flex flex-wrap justify-center gap-2 md:gap-4">
              {filters.map(f => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={`px-6 py-2 rounded-full text-sm transition-all duration-300 border ${
                    filter === f 
                      ? 'bg-foreground text-background border-foreground' 
                      : 'bg-transparent text-foreground border-border hover:border-foreground'
                  }`}
                >
                  {f}
                </button>
              ))}
            </div>
          </FadeIn>
        </div>
      </section>

      <section className="py-24 bg-background min-h-screen">
        <div className="container mx-auto px-4">
          <motion.div 
            layout 
            className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6"
          >
            <AnimatePresence>
              {filteredImages.map((img) => (
                <motion.div
                  key={img.id}
                  layout
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                  transition={{ duration: 0.3 }}
                  className="relative group cursor-pointer break-inside-avoid overflow-hidden rounded-sm"
                  onClick={() => setLightboxImg(img.src)}
                >
                  <img 
                    src={img.src} 
                    alt={img.alt} 
                    className="w-full object-cover group-hover:scale-105 transition-transform duration-700" 
                  />
                  <div className="absolute inset-0 bg-foreground/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center backdrop-blur-[2px]">
                    <ZoomIn className="text-white w-10 h-10" />
                  </div>
                </motion.div>
              ))}
            </AnimatePresence>
          </motion.div>
        </div>
      </section>

      {/* Lightbox */}
      <AnimatePresence>
        {lightboxImg && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[100] bg-background/95 backdrop-blur-md flex items-center justify-center p-4 md:p-12"
            onClick={() => setLightboxImg(null)}
          >
            <button 
              className="absolute top-6 right-6 text-foreground hover:text-accent transition-colors"
              onClick={() => setLightboxImg(null)}
            >
              <X size={32} strokeWidth={1} />
            </button>
            <img 
              src={lightboxImg} 
              alt="Expanded view" 
              className="max-w-full max-h-[90vh] object-contain shadow-2xl rounded-sm" 
              onClick={e => e.stopPropagation()}
            />
          </motion.div>
        )}
      </AnimatePresence>
    </Layout>
  );
}
