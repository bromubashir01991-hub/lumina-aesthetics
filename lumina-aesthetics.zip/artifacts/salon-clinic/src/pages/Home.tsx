import { Layout } from '@/components/layout/Layout';
import { FadeIn } from '@/components/ui/FadeIn';
import { Button } from '@/components/ui/button';
import { ArrowRight, Star, CheckCircle, Droplets, Sparkles, Activity, Zap } from 'lucide-react';
import { Link } from 'wouter';
import { services, testimonials, blogPosts } from '@/lib/data';
import { motion } from 'framer-motion';

export default function Home() {
  const features = [
    "Doctor Performed", "FDA Approved", "Custom Plans", "Latest Equipment",
    "Experienced Staff", "Safe Procedures", "Follow-up Care", "Affordable Packages"
  ];

  return (
    <Layout>
      {/* HERO SECTION */}
      <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden pt-20">
        <div className="absolute inset-0 bg-gradient-to-b from-primary/30 to-background -z-20" />
        
        {/* Animated Blob Background */}
        <motion.div 
          className="absolute inset-0 -z-10 opacity-60 flex items-center justify-center pointer-events-none"
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <img src="/images/hero-blob.png" alt="" className="w-[80vw] max-w-[800px] object-contain opacity-40 blur-sm" />
        </motion.div>

        <div className="container mx-auto px-4 text-center z-10">
          <FadeIn delay={0.1}>
            <span className="text-accent uppercase tracking-[0.3em] text-sm font-semibold mb-6 block">Lumina Aesthetics</span>
          </FadeIn>
          
          <FadeIn delay={0.3} direction="up">
            <h1 className="font-serif text-5xl md:text-7xl lg:text-[90px] leading-[1.1] text-foreground mb-8 mx-auto max-w-4xl">
              <span className="italic font-light">Reveal Your Most</span><br />
              Beautiful Skin
            </h1>
          </FadeIn>
          
          <FadeIn delay={0.5} direction="up">
            <p className="font-sans font-light text-muted-foreground text-lg md:text-xl max-w-[500px] mx-auto mb-10 leading-relaxed">
              Doctor-supervised aesthetic treatments designed to restore confidence and enhance natural beauty.
            </p>
          </FadeIn>
          
          <FadeIn delay={0.7} direction="up">
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button href="/book" variant="gold" size="lg" className="w-full sm:w-auto rounded-none">
                Book Appointment
              </Button>
              <Button href="/services" variant="outline" size="lg" className="w-full sm:w-auto rounded-none border-foreground text-foreground hover:bg-foreground hover:text-background">
                Explore Services
              </Button>
            </div>
          </FadeIn>
        </div>
      </section>

      {/* STATS BAR */}
      <section className="bg-foreground text-background py-16">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center divide-x divide-background/20">
            <FadeIn delay={0.1}>
              <div className="font-serif text-4xl md:text-5xl text-accent mb-2">15K+</div>
              <div className="text-sm tracking-wider uppercase opacity-80">Happy Clients</div>
            </FadeIn>
            <FadeIn delay={0.2}>
              <div className="font-serif text-4xl md:text-5xl text-accent mb-2">10+</div>
              <div className="text-sm tracking-wider uppercase opacity-80">Years Experience</div>
            </FadeIn>
            <FadeIn delay={0.3}>
              <div className="font-serif text-4xl md:text-5xl text-accent mb-2">100%</div>
              <div className="text-sm tracking-wider uppercase opacity-80">FDA Approved</div>
            </FadeIn>
            <FadeIn delay={0.4}>
              <div className="font-serif text-4xl md:text-5xl text-accent mb-2">24/7</div>
              <div className="text-sm tracking-wider uppercase opacity-80">Doctor Supervised</div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* ABOUT PREVIEW */}
      <section className="py-24 md:py-32 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <FadeIn direction="right">
              <div className="relative">
                <div className="absolute inset-0 bg-accent/20 translate-x-4 translate-y-4 -z-10" />
                <img 
                  src="/images/clinic-interior.jpg" 
                  alt="Lumina Clinic Interior" 
                  className="w-full aspect-[4/5] object-cover shadow-2xl"
                />
              </div>
            </FadeIn>
            <FadeIn direction="left">
              <div className="max-w-xl">
                <h2 className="font-serif text-4xl md:text-5xl mb-6">Your skin tells your story — <span className="italic text-accent">let us help you write a beautiful chapter.</span></h2>
                <p className="text-muted-foreground font-light text-lg mb-8 leading-relaxed">
                  At Lumina Aesthetics, we believe that true luxury lies in subtlety and precision. Our medical-grade treatments are tailored specifically to your unique biology, ensuring results that are undeniably radiant yet profoundly natural.
                </p>
                <Button href="/about" variant="ghost" className="px-0 hover:bg-transparent hover:text-accent flex items-center gap-2 group text-lg">
                  Our Story <ArrowRight size={18} className="group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </FadeIn>
          </div>
        </div>
      </section>

      {/* SERVICES PREVIEW */}
      <section className="py-24 bg-secondary/50">
        <div className="container mx-auto px-4">
          <FadeIn className="text-center mb-16">
            <span className="text-accent uppercase tracking-widest text-sm font-semibold mb-4 block">What We Do</span>
            <h2 className="font-serif text-4xl md:text-5xl">Our Treatments</h2>
          </FadeIn>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {services.slice(0, 6).map((service, idx) => (
              <FadeIn key={service.id} delay={idx * 0.1}>
                <Link href={`/services/${service.slug}`} className="group block h-full">
                  <div className="bg-card p-8 border border-border h-full transition-all duration-500 hover:-translate-y-2 hover:shadow-[0_20px_40px_-15px_rgba(0,0,0,0.05)] hover:border-accent/30 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-primary/20 rounded-bl-full -mr-4 -mt-4 transition-transform group-hover:scale-150 duration-500" />
                    
                    <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center mb-6 text-foreground group-hover:text-accent group-hover:bg-primary/20 transition-colors">
                      {/* Using generic icon for preview */}
                      <Sparkles size={24} strokeWidth={1.5} />
                    </div>
                    
                    <h3 className="font-serif text-2xl mb-3">{service.name}</h3>
                    <p className="text-muted-foreground font-light mb-6 line-clamp-2">{service.shortDesc}</p>
                    
                    <div className="flex items-center text-sm font-medium text-foreground group-hover:text-accent transition-colors mt-auto">
                      Learn More <ArrowRight size={16} className="ml-2 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </div>
                </Link>
              </FadeIn>
            ))}
          </div>

          <FadeIn className="text-center">
            <Button href="/services" variant="outline" className="rounded-none border-foreground text-foreground">
              View All Services
            </Button>
          </FadeIn>
        </div>
      </section>

      {/* WHY CHOOSE US */}
      <section className="py-24 bg-background border-t border-border">
        <div className="container mx-auto px-4">
          <FadeIn className="text-center mb-16 max-w-2xl mx-auto">
            <h2 className="font-serif text-4xl md:text-5xl mb-6">The Lumina Standard</h2>
            <p className="text-muted-foreground font-light">We hold ourselves to the highest medical standards, ensuring your safety, comfort, and exceptional results.</p>
          </FadeIn>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 lg:gap-8">
            {features.map((feature, idx) => (
              <FadeIn key={idx} delay={idx * 0.05} className="flex flex-col items-center text-center p-6 bg-secondary/30 border border-border/50">
                <CheckCircle className="text-accent mb-4" size={28} strokeWidth={1.5} />
                <h4 className="font-serif text-lg">{feature}</h4>
              </FadeIn>
            ))}
          </div>
        </div>
      </section>

      {/* TESTIMONIALS PREVIEW */}
      <section className="py-24 bg-secondary text-center">
        <div className="container mx-auto px-4">
          <FadeIn>
            <h2 className="font-serif text-4xl md:text-5xl mb-16">Client Experiences</h2>
          </FadeIn>

          <div className="grid md:grid-cols-3 gap-8 mb-12">
            {testimonials.slice(0, 3).map((test, idx) => (
              <FadeIn key={idx} delay={idx * 0.1}>
                <div className="bg-card p-8 border border-border text-left relative h-full flex flex-col">
                  <div className="flex items-center gap-1 text-accent mb-6">
                    {[...Array(test.rating)].map((_, i) => (
                      <Star key={i} size={16} fill="currentColor" />
                    ))}
                  </div>
                  <p className="font-serif text-lg leading-relaxed mb-8 flex-1 italic text-muted-foreground">"{test.quote}"</p>
                  <div className="flex items-center gap-4 mt-auto">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-secondary">
                      {test.image ? (
                        <img src={test.image} alt={test.name} className="w-full h-full object-cover" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-accent font-serif text-xl bg-primary/30">
                          {test.name.charAt(0)}
                        </div>
                      )}
                    </div>
                    <div>
                      <h4 className="font-sans font-medium text-sm">{test.name}</h4>
                      <p className="text-xs text-muted-foreground">{test.treatment}</p>
                    </div>
                  </div>
                </div>
              </FadeIn>
            ))}
          </div>
          
          <FadeIn>
            <Button href="/testimonials" variant="ghost" className="text-foreground hover:text-accent">
              Read All Reviews <ArrowRight size={16} className="ml-2" />
            </Button>
          </FadeIn>
        </div>
      </section>

      {/* BLOG PREVIEW */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4">
          <FadeIn className="flex justify-between items-end mb-12">
            <div>
              <span className="text-accent uppercase tracking-widest text-sm font-semibold mb-4 block">Journal</span>
              <h2 className="font-serif text-4xl">Expert Insights</h2>
            </div>
            <Link href="/blog" className="hidden md:flex items-center gap-2 text-sm font-medium hover:text-accent transition-colors">
              View All <ArrowRight size={16} />
            </Link>
          </FadeIn>

          <div className="grid md:grid-cols-3 gap-8">
            {blogPosts.slice(0, 3).map((post, idx) => (
              <FadeIn key={post.slug} delay={idx * 0.1}>
                <Link href={`/blog/${post.slug}`} className="group block">
                  <div className="aspect-[4/3] overflow-hidden mb-6 relative">
                    <img 
                      src={post.image} 
                      alt={post.title} 
                      className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                    />
                    <div className="absolute top-4 left-4 bg-background/90 backdrop-blur text-xs font-semibold px-3 py-1 uppercase tracking-wider text-accent">
                      {post.category}
                    </div>
                  </div>
                  <h3 className="font-serif text-2xl mb-3 group-hover:text-accent transition-colors">{post.title}</h3>
                  <p className="text-muted-foreground font-light mb-4 line-clamp-2">{post.excerpt}</p>
                  <span className="text-sm font-medium uppercase tracking-wider underline decoration-accent/30 underline-offset-4 group-hover:decoration-accent transition-colors">Read Article</span>
                </Link>
              </FadeIn>
            ))}
          </div>
          
          <div className="mt-8 text-center md:hidden">
            <Button href="/blog" variant="outline" className="w-full rounded-none">View All Posts</Button>
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-32 bg-primary relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.4)_0%,transparent_100%)]" />
        <div className="container mx-auto px-4 text-center relative z-10">
          <FadeIn>
            <h2 className="font-serif text-5xl md:text-6xl mb-6">Ready for Your Transformation?</h2>
            <p className="text-foreground/80 font-light text-lg md:text-xl max-w-2xl mx-auto mb-10">
              Schedule your comprehensive consultation and let our experts design a tailored aesthetic journey just for you.
            </p>
            <Button href="/book" variant="gold" size="lg" className="rounded-none text-lg px-10">
              Book Your Consultation
            </Button>
          </FadeIn>
        </div>
      </section>
    </Layout>
  );
}
