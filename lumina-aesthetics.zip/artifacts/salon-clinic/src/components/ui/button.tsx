import { ReactNode } from 'react';
import { motion } from 'framer-motion';
import { Link } from 'wouter';
import { cn } from '@/lib/utils';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'outline' | 'ghost' | 'gold';
  size?: 'sm' | 'md' | 'lg';
  children: ReactNode;
  as?: any;
  href?: string;
}

export function Button({
  className,
  variant = 'primary',
  size = 'md',
  children,
  as: Component = 'button',
  href,
  ...props
}: ButtonProps) {
  const baseStyles = "inline-flex items-center justify-center font-sans font-semibold transition-all duration-300 ease-out focus:outline-none disabled:opacity-50 disabled:cursor-not-allowed tracking-wide relative overflow-hidden group";
  
  const variants = {
    primary: "bg-accent text-white hover:bg-[#b88c67] shadow-sm hover:shadow-md",
    outline: "border-2 border-accent text-accent hover:bg-accent hover:text-white",
    ghost: "text-foreground hover:text-accent hover:bg-primary/20",
    gold: "bg-[#D4AF37] text-white hover:bg-[#c29f2f] shadow-sm hover:shadow-md"
  };

  const sizes = {
    sm: "px-4 py-2 text-sm",
    md: "px-6 py-3 text-sm md:text-base",
    lg: "px-8 py-4 text-base md:text-lg"
  };

  const isLink = !!href;
  const Wrapper = isLink ? Link : motion.button;
  const wrapperProps = isLink ? { href, className: cn(baseStyles, variants[variant], sizes[size], className) } : {
    className: cn(baseStyles, variants[variant], sizes[size], className),
    whileHover: { scale: 1.02 },
    whileTap: { scale: 0.98 },
    ...props
  };

  return (
    <Wrapper {...wrapperProps}>
      {/* Ripple effect overlay */}
      <span className="absolute inset-0 w-full h-full bg-white/20 scale-0 group-hover:scale-100 group-hover:opacity-0 rounded-full transition-all duration-700 ease-out origin-center pointer-events-none"></span>
      <span className="relative z-10">{children}</span>
    </Wrapper>
  );
}
