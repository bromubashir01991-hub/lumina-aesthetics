import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, useLocation } from 'wouter';
import { Menu, X } from 'lucide-react';
import { Button } from '../ui/button';
import { cn } from '@/lib/utils';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [location] = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = [
    { name: 'Home', href: '/' },
    { name: 'About', href: '/about' },
    { name: 'Services', href: '/services' },
    { name: 'Gallery', href: '/gallery' },
    { name: 'Before & After', href: '/before-after' },
    { name: 'Testimonials', href: '/testimonials' },
    { name: 'Blog', href: '/blog' },
    { name: 'FAQs', href: '/faqs' },
    { name: 'Contact', href: '/contact' },
  ];

  const isHome = location === '/';
  
  // Only transparent at top of home page
  const isTransparent = isHome && !isScrolled;

  return (
    <header 
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500 ease-in-out border-b border-transparent",
        isTransparent 
          ? "bg-transparent py-6" 
          : "glass-dark py-4 luxury-shadow border-white/20"
      )}
    >
      <div className="container mx-auto px-4 md:px-8 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2 group">
          <span className={cn(
            "font-serif text-3xl tracking-wider transition-colors duration-300",
            isTransparent ? "text-foreground" : "text-foreground"
          )}>
            LUMINA
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden lg:flex items-center gap-8">
          <ul className="flex items-center gap-6">
            {links.map((link) => (
              <li key={link.name}>
                <Link 
                  href={link.href}
                  className={cn(
                    "text-sm font-medium tracking-wide transition-colors hover:text-accent relative after:absolute after:-bottom-1 after:left-0 after:w-full after:h-[1px] after:bg-accent after:origin-right after:scale-x-0 hover:after:scale-x-100 hover:after:origin-left after:transition-transform after:duration-300",
                    location === link.href ? "text-accent after:scale-x-100" : (isTransparent ? "text-foreground/80" : "text-muted-foreground")
                  )}
                >
                  {link.name}
                </Link>
              </li>
            ))}
          </ul>
          
          <Button href="/book" variant="primary" size="sm" className="hidden xl:flex rounded-none">
            Book Appointment
          </Button>
        </nav>

        {/* Mobile Toggle */}
        <button 
          className="lg:hidden text-foreground p-2"
          onClick={() => setMobileMenuOpen(true)}
          aria-label="Open menu"
        >
          <Menu size={28} strokeWidth={1.5} />
        </button>
      </div>

      {/* Mobile Drawer */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 lg:hidden"
              onClick={() => setMobileMenuOpen(false)}
            />
            <motion.div 
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed top-0 right-0 bottom-0 w-[85vw] max-w-sm bg-background border-l border-border z-50 flex flex-col shadow-2xl lg:hidden"
            >
              <div className="flex items-center justify-between p-6 border-b border-border">
                <span className="font-serif text-2xl tracking-widest text-foreground">LUMINA</span>
                <button 
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2 text-muted-foreground hover:text-foreground transition-colors"
                >
                  <X size={24} strokeWidth={1.5} />
                </button>
              </div>
              
              <div className="flex-1 overflow-y-auto py-8 px-6">
                <ul className="flex flex-col gap-6">
                  {links.map((link) => (
                    <motion.li 
                      key={link.name}
                      initial={{ opacity: 0, x: 20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: 0.1 }}
                    >
                      <Link 
                        href={link.href}
                        onClick={() => setMobileMenuOpen(false)}
                        className={cn(
                          "text-xl font-serif tracking-wide block transition-colors",
                          location === link.href ? "text-accent italic" : "text-foreground"
                        )}
                      >
                        {link.name}
                      </Link>
                    </motion.li>
                  ))}
                </ul>
              </div>
              
              <div className="p-6 border-t border-border">
                <Button href="/book" variant="primary" className="w-full justify-center rounded-none" onClick={() => setMobileMenuOpen(false)}>
                  Book Appointment
                </Button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </header>
  );
}
