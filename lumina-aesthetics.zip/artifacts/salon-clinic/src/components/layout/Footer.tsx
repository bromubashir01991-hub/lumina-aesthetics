import { Link } from 'wouter';
import { Instagram, Facebook, MessageCircle, MapPin, Phone, Mail } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-secondary pt-20 pb-10 border-t border-border">
      <div className="container mx-auto px-4 md:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8 mb-16">
          
          {/* Brand */}
          <div className="flex flex-col gap-6">
            <span className="font-serif text-3xl tracking-widest text-foreground">LUMINA</span>
            <p className="text-muted-foreground font-sans font-light leading-relaxed max-w-sm">
              Where science meets luxury. Doctor-supervised aesthetic treatments designed to restore confidence and enhance your natural beauty.
            </p>
            <div className="flex items-center gap-4 mt-2">
              <a href="#" className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-accent hover:text-white hover:border-accent transition-all duration-300">
                <Instagram size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-accent hover:text-white hover:border-accent transition-all duration-300">
                <Facebook size={18} />
              </a>
              <a href="#" className="w-10 h-10 rounded-full border border-border flex items-center justify-center text-foreground hover:bg-[#25D366] hover:text-white hover:border-[#25D366] transition-all duration-300">
                <MessageCircle size={18} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div className="flex flex-col gap-6">
            <h4 className="font-serif text-xl text-foreground">Quick Links</h4>
            <ul className="flex flex-col gap-3">
              {['Home', 'About', 'Gallery', 'Testimonials', 'Blog', 'FAQs'].map((link) => (
                <li key={link}>
                  <Link href={link === 'Home' ? '/' : `/${link.toLowerCase()}`} className="text-muted-foreground hover:text-accent transition-colors font-light">
                    {link}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div className="flex flex-col gap-6">
            <h4 className="font-serif text-xl text-foreground">Treatments</h4>
            <ul className="flex flex-col gap-3">
              {['HydraFacial', 'Laser Hair Removal', 'PRP Therapy', 'Skin Tightening', 'Anti-Aging', 'Skin Analysis'].map((service) => (
                <li key={service}>
                  <Link href={`/services`} className="text-muted-foreground hover:text-accent transition-colors font-light">
                    {service}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div className="flex flex-col gap-6">
            <h4 className="font-serif text-xl text-foreground">Contact Us</h4>
            <ul className="flex flex-col gap-4">
              <li className="flex items-start gap-3 text-muted-foreground font-light">
                <MapPin size={18} className="mt-1 flex-shrink-0 text-accent" />
                <span>12-A Main Gulberg III<br/>Lahore, Punjab, Pakistan</span>
              </li>
              <li className="flex items-center gap-3 text-muted-foreground font-light">
                <Phone size={18} className="flex-shrink-0 text-accent" />
                <span>+92 42 3576 8800</span>
              </li>
              <li className="flex items-center gap-3 text-muted-foreground font-light">
                <Mail size={18} className="flex-shrink-0 text-accent" />
                <span>hello@luminaaesthetics.pk</span>
              </li>
            </ul>
          </div>

        </div>

        <div className="border-t border-border/60 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground font-light">
          <p>© {new Date().getFullYear()} Lumina Aesthetics. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-accent transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-accent transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
